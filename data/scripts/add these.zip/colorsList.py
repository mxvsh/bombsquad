# -*- coding: utf-8 -*-

gAdminColors = [(0.0, 2.677760124206543, 0.6802000999450684),(1.0,10.0,4.0),(1.0,4.0,10.0)]
gCreatorColors = [(5.340000152587891, 5.340000152587891, 5.340000152587891)]
gGodColors = [(1.1499923467636108, 0.10000409185886383, 2.0)]
gFriendColors = [(0.5199999809265137, 1.9500000476837158, 0.019999999552965164)]
gArenaCloserColors = [(4.0, 3.380000114440918, 0.8600000143051147)]
gLuckyColors = [(0.12999999523162842, 1.4700000286102295, 1.9900000095367432)]

gBannedNames = [u'nur',u'чужой',u'нурб0л',u'pc97374',u'safeunicorn',u'frozone',u'медет',u'nurbol',u'nurb0l',u'персона',u'thirstyfly',u'#hulk',u'#iron',u'jeka0370',u'jеka0370',
                u'Medet',u'амбас',u'повар',u'лидер',u'нурбол',u'нур',u'gladio',u'романтик',u'персона',u'я в тени',u'нур',u'hyp',u'hур',u'нуp',u'нyр',u'hero hit',u'catchoo83',
                u'тени',u'medet',u'( * * )',u'(* *)',u'(*  *)',u'( *  * )',u' ',u'нуpб0л',u'hуpб0л',u'hурб0л',u'нурбoл',u'нуpбoл',u'hурбoл',u'den4ic',u'dan4ic',u'ninjagamer',
                u'aren-god',u'hyp',u'нyр',u'pc94195',u'android14655052',u'pc91907',u'vip2017',u'pc98438',u'pc98443',u'€v€',u'dan4ik',u'denчik',u'noob',u'herokiller',u'hero hit',
                u'мина',u'хищник',u'загадка',u'lili',u'honam',u'spazzy',u'îmâ',u'hitman',u'bon-bon',u'dramaticchief',u'thunder18',u'htman',u'android12925950',u'ronald mc',u'mariatrey',
                u'den4ik',u'бот 2013',u'bear ro',u'epicninja',u'alex dk',u'михакер',u'mixaker',u'ме дет',u'мед ет',u'едет',u'м едет',u'рбол',u'ну рб0л',u'долба',u'подарочек',u'falcon',u'miclo',
                u'nightmare',u'amine',u'medеt',u'mеdet',u'medет',u'mеdeт',u'persona',u'persоna',u'personа',u'persоnа',u'himan',u'hman',u'hit man',u'himon',u'htmn',u'hitmn',u'frost',
                u'беззубик',u'polak',u'fire',u'200202',u'crusheratomic',u'putridbanana',u'whiте',u'whiтe',u'miguelinw',u'пипка','perdelka',u'android14383081']